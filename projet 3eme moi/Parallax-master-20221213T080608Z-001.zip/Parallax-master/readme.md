## CREATING PURE CSS PARALLAX EFFECTS...

- Exploring creating a parallax without using javascript to manipulate scoll events.

- live: http://johnrbell.github.io/Parallax/

- credit to hipsum.co for the hipster ipsum. 